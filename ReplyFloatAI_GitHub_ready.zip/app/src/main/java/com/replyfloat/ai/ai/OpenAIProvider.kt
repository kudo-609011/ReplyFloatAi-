package com.replyfloat.ai.ai

import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.replyfloat.ai.model.AIProviderConfig
import com.replyfloat.ai.model.ReplyRequest
import com.replyfloat.ai.model.ReplySuggestion
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

class OpenAIProvider(
    private val config: AIProviderConfig,
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .build(),
    private val gson: Gson = Gson()
) : AIProvider {

    override val id: String = config.id
    override val name: String = config.name

    override suspend fun generateReplies(request: ReplyRequest): Result<List<ReplySuggestion>> =
        withContext(Dispatchers.IO) {
            try {
                val apiKey = config.apiKey
                if (apiKey.isBlank()) {
                    return@withContext Result.failure(IllegalStateException("API key is required."))
                }

                val endpoint = config.endpoint.ifBlank { "https://api.openai.com/v1/chat/completions" }
                val model = config.model.ifBlank { "gpt-4o-mini" }

                val systemPrompt = "You are ReplyFloat AI. Generate ${request.count} reply options in ${request.style} style. Return JSON: {\\\"replies\\\": [{\\\"text\\\": \\\"...\\\", \\\"style\\\": \\\"${request.style}\\\"}]}"

                val payload = JsonObject().apply {
                    addProperty("model", model)
                    val messages = JsonArray().apply {
                        add(JsonObject().apply {
                            addProperty("role", "system")
                            addProperty("content", systemPrompt)
                        })
                        add(JsonObject().apply {
                            addProperty("role", "user")
                            addProperty("content", "Context text: ${request.conversationText}")
                        })
                    }
                    add("messages", messages)
                    addProperty("temperature", 0.7)
                }

                val body = payload.toString().toRequestBody("application/json".toMediaType())
                val httpRequest = Request.Builder()
                    .url(endpoint)
                    .addHeader("Authorization", "Bearer $apiKey")
                    .addHeader("Content-Type", "application/json")
                    .post(body)
                    .build()

                val response = client.newCall(httpRequest).execute()
                if (!response.isSuccessful) {
                    val err = response.body?.string() ?: "HTTP ${response.code}"
                    return@withContext Result.failure(Exception("AI Provider Error: $err"))
                }

                val resBody = response.body?.string() ?: ""
                val rootJson = gson.fromJson(resBody, JsonObject::class.java)
                val choices = rootJson.getAsJsonArray("choices")
                val content = choices?.get(0)?.asJsonObject?.getAsJsonObject("message")?.get("content")?.asString ?: ""

                val list = mutableListOf<ReplySuggestion>()
                val jsonMatch = Regex("""\{.*\}""", RegexOption.DOT_MATCHES_ALL).find(content)?.value
                if (jsonMatch != null) {
                    val parsed = gson.fromJson(jsonMatch, JsonObject::class.java)
                    parsed.getAsJsonArray("replies")?.forEachIndexed { idx, elem ->
                        val obj = elem.asJsonObject
                        list.add(
                            ReplySuggestion(
                                id = idx.toString(),
                                style = obj.get("style")?.asString ?: request.style,
                                text = obj.get("text")?.asString ?: "",
                                tone = request.style
                            )
                        )
                    }
                } else {
                    content.lines().filter { it.isNotBlank() }.take(request.count).forEachIndexed { i, l ->
                        list.add(ReplySuggestion(i.toString(), request.style, l.trim(), request.style))
                    }
                }

                Result.success(list)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    override suspend fun testConnection(): Result<Boolean> = withContext(Dispatchers.IO) {
        val dummy = ReplyRequest("Hi", "Short", 1, "short")
        generateReplies(dummy).map { true }
    }
}

class CustomOpenAICompatibleProvider(config: AIProviderConfig) : AIProvider by OpenAIProvider(config)
