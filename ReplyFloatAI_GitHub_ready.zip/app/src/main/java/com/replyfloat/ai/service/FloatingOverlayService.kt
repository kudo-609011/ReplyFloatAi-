package com.replyfloat.ai.service

import android.annotation.SuppressLint
import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.*
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.NotificationCompat
import androidx.lifecycle.*
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.replyfloat.ai.MainActivity
import com.replyfloat.ai.R
import com.replyfloat.ai.ReplyFloatApplication
import com.replyfloat.ai.ai.AIProviderManager
import com.replyfloat.ai.data.AppPreferencesRepository
import com.replyfloat.ai.model.AIProviderConfig
import com.replyfloat.ai.model.ReplyRequest
import com.replyfloat.ai.model.ReplySuggestion
import com.replyfloat.ai.ui.overlay.FloatingOverlayContent
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first

/**
 * Service managing the floating interactive and transparent overlay.
 * Supports "Pass-Through Mode" using FLAG_NOT_TOUCHABLE so underlying apps
 * receive all touch events when pass-through is active.
 */
class FloatingOverlayService : Service(), LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {

    private lateinit var windowManager: WindowManager
    private var overlayComposeView: ComposeView? = null
    private lateinit var layoutParams: WindowManager.LayoutParams
    private val detectedText = mutableStateOf("")
    private val detectedPackage = mutableStateOf("")

    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val lifecycleRegistry = LifecycleRegistry(this)
    private val store = ViewModelStore()
    private val savedStateRegistryController = SavedStateRegistryController.create(this)

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val viewModelStore: ViewModelStore get() = store
    override val savedStateRegistry: SavedStateRegistry get() = savedStateRegistryController.savedStateRegistry

    companion object {
        const val ACTION_START = "ACTION_START_OVERLAY"
        const val ACTION_STOP = "ACTION_STOP_OVERLAY"
        const val ACTION_UPDATE_TEXT = "ACTION_UPDATE_TEXT"
        const val EXTRA_DETECTED_TEXT = "EXTRA_DETECTED_TEXT"
        const val EXTRA_PACKAGE_NAME = "EXTRA_PACKAGE_NAME"

        fun startService(context: Context, text: String = "", pkg: String = "") {
            val intent = Intent(context, FloatingOverlayService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_DETECTED_TEXT, text)
                putExtra(EXTRA_PACKAGE_NAME, pkg)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, FloatingOverlayService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }

    override fun onCreate() {
        super.onCreate()
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                removeOverlay()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            else -> {
                startForeground(1001, createNotification())
                val text = intent?.getStringExtra(EXTRA_DETECTED_TEXT) ?: ""
                val packageName = intent?.getStringExtra(EXTRA_PACKAGE_NAME) ?: ""
                if (overlayComposeView == null) {
                    showOverlay(text, packageName)
                } else {
                    updateOverlayText(text, packageName)
                }
            }
        }
        return START_STICKY
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun showOverlay(initialText: String, initialPackage: String) {
        detectedText.value = initialText
        detectedPackage.value = initialPackage

        val windowType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        // Default layout flags: Not focusable, not touch modal, fits system windows
        layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            windowType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 100
            y = 300
        }

        val composeView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@FloatingOverlayService)
            setViewTreeViewModelStoreOwner(this@FloatingOverlayService)
            setViewTreeSavedStateRegistryOwner(this@FloatingOverlayService)

            setContent {
                FloatingOverlayContent(
                    initialText = detectedText.value,
                    initialPackage = detectedPackage.value,
                    onClose = {
                        stopForeground(STOP_FOREGROUND_REMOVE)
                        stopSelf()
                    },
                    onDrag = { dx, dy ->
                        updateOverlayPosition(dx, dy)
                    },
                    onTogglePassThrough = { isPassThrough ->
                        setPassThroughMode(isPassThrough)
                    },
                    onGenerate = { text -> generateReplies(text) }
                )
            }
        }

        overlayComposeView = composeView
        windowManager.addView(composeView, layoutParams)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)
    }

    private fun updateOverlayPosition(dx: Float, dy: Float) {
        layoutParams.x += dx.toInt()
        layoutParams.y += dy.toInt()
        overlayComposeView?.let { windowManager.updateViewLayout(it, layoutParams) }
    }

    /**
     * Reads the current settings, builds the active AI provider, and requests
     * reply suggestions for the given on-screen text. This is the real bridge
     * between what the accessibility service detects and the Gemini/OpenAI API.
     */
    private suspend fun generateReplies(text: String): Result<List<ReplySuggestion>> {
        if (text.isBlank()) return Result.success(emptyList())
        val repo = AppPreferencesRepository.getInstance(applicationContext)

        val activeProviderId = repo.activeProvider.first()
        val style = repo.replyStyle.first()
        val count = repo.suggestionCount.first()
        val length = repo.responseLength.first()

        val config = when (activeProviderId) {
            "openai" -> AIProviderConfig(
                id = "openai",
                name = "OpenAI",
                type = "openai",
                endpoint = repo.getOpenAIEndpoint().first(),
                model = repo.getOpenAIModel().first(),
                apiKey = repo.getOpenAIKey().first()
            )
            else -> AIProviderConfig(
                id = "gemini",
                name = "Gemini",
                type = "gemini",
                endpoint = "",
                model = "gemini-3.7-flash",
                apiKey = repo.getGeminiKey().first()
            )
        }

        val provider = AIProviderManager.createProvider(config)
        val manager = AIProviderManager(mapOf(config.id to provider))

        return manager.generateReplies(
            providerId = config.id,
            request = ReplyRequest(
                conversationText = text,
                style = style,
                count = count,
                length = length
            )
        )
    }

    /**
     * Toggles touch pass-through.
     * When passThrough == true: add FLAG_NOT_TOUCHABLE so touches pass directly to the underlying app!
     */
    private fun setPassThroughMode(passThrough: Boolean) {
        val view = overlayComposeView ?: return
        if (passThrough) {
            layoutParams.flags = layoutParams.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        } else {
            layoutParams.flags = layoutParams.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        }
        windowManager.updateViewLayout(view, layoutParams)
    }

    private fun updateOverlayText(text: String, pkg: String) {
        detectedText.value = text
        detectedPackage.value = pkg
    }

    private fun removeOverlay() {
        overlayComposeView?.let {
            try {
                windowManager.removeView(it)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            overlayComposeView = null
        }
    }

    private fun createNotification(): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, FloatingOverlayService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, ReplyFloatApplication.CHANNEL_ID)
            .setContentTitle("ReplyFloat AI Active")
            .setContentText("Tap to open settings or manage floating overlay")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(pendingIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop Overlay", stopIntent)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        removeOverlay()
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
