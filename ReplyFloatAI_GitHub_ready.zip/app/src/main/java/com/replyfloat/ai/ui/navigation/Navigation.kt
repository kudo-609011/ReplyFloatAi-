package com.replyfloat.ai.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.compose.material3.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.replyfloat.ai.ui.viewmodel.MainViewModel

@Composable fun ReplyFloatNavHost(navController:NavHostController, viewModel:MainViewModel, onRequestOverlayPermission:()->Unit, onRequestAccessibilityPermission:()->Unit){
 NavHost(navController,"home"){ composable("home"){ Home(viewModel,onRequestOverlayPermission,onRequestAccessibilityPermission)}; composable("history"){ History(viewModel)} }
}
@Composable private fun Home(vm:MainViewModel, overlay:()->Unit, accessibility:()->Unit){
 val state by vm.state.collectAsState()
 Column(Modifier.fillMaxSize().padding(20.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
  Text("ReplyFloat AI",style=MaterialTheme.typography.headlineMedium); Text("Floating contextual reply assistant",style=MaterialTheme.typography.bodyMedium)
  Row(horizontalArrangement=Arrangement.spacedBy(12.dp)){ Button(onClick=overlay){Text("Overlay permission")}; Button(onClick=accessibility){Text("Accessibility")}}
  Row(horizontalArrangement=Arrangement.spacedBy(12.dp)){ Text("Analyze screen"); Switch(checked=state.enabled,onCheckedChange=vm::setEnabled) }
  Text("Reply mode"); var expanded=androidx.compose.runtime.remember{false}; Box{ OutlinedButton(onClick={expanded=true}){Text(state.style)}; DropdownMenu(expanded,{expanded=false}){vm.styles.forEach{DropdownMenuItem(text={Text(it)},onClick={expanded=false;vm.setStyle(it)})}} }
  OutlinedTextField(value=state.geminiKey,onValueChange=vm::setGeminiKey,label={Text("Gemini API key")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Password),modifier=Modifier.fillMaxWidth())
  Button(onClick=vm::saveSettings){Text("Save settings")}; Text("History: ${state.history.size}"); if(state.history.isNotEmpty()){Text("Latest: ${state.history.last().text}")}
  Button(onClick=vm::clearHistory){Text("Clear history")}
 }
}
@Composable private fun History(vm:MainViewModel){ val state by vm.state.collectAsState(); Column(Modifier.fillMaxSize().padding(20.dp)){Text("Reply history",style=MaterialTheme.typography.headlineSmall); state.history.asReversed().forEach{ Text(it.text,Modifier.padding(vertical=8.dp)) } } }
