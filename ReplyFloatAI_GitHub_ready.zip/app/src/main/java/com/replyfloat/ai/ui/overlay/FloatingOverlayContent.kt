package com.replyfloat.ai.ui.overlay

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.replyfloat.ai.model.ReplySuggestion

data class OverlayReply(
    val id: Long,
    val question: String,
    val text: String,
    val time: Long = System.currentTimeMillis()
)

@Composable
fun FloatingOverlayContent(
    initialText: String,
    initialPackage: String,
    onClose: () -> Unit,
    onDrag: (Float, Float) -> Unit,
    onTogglePassThrough: (Boolean) -> Unit,
    onGenerate: suspend (String) -> Result<List<ReplySuggestion>>
) {
    var question by remember { mutableStateOf(initialText) }
    var replies by remember { mutableStateOf(listOf<OverlayReply>()) }
    var expanded by remember { mutableStateOf(false) }
    var passThrough by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    val clipboard = LocalClipboardManager.current

    // Keep in sync with newly detected on-screen text
    LaunchedEffect(initialText) {
        if (initialText.isNotBlank() && initialText != question) {
            question = initialText
        }
    }

    // Whenever the detected text changes, actually ask the AI for replies.
    LaunchedEffect(question) {
        if (question.isBlank()) return@LaunchedEffect
        loading = true
        errorMessage = null
        val result = onGenerate(question)
        loading = false
        result.onSuccess { suggestions ->
            if (suggestions.isNotEmpty()) {
                val newReplies = suggestions.map {
                    OverlayReply(id = System.nanoTime() + it.id.hashCode(), question = question, text = it.text)
                }
                replies = (replies + newReplies).takeLast(20)
            }
        }.onFailure { e ->
            errorMessage = e.message ?: "Failed to generate a reply."
        }
    }

    Card(
        modifier = Modifier
            .widthIn(min = 260.dp, max = 360.dp)
            .pointerInput(Unit) {
                detectDragGestures { change, drag ->
                    change.consume()
                    onDrag(drag.x, drag.y)
                }
            }
    ) {
        Column(Modifier.padding(12.dp).background(MaterialTheme.colorScheme.surface)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("ReplyFloat AI", fontSize = 16.sp)
                Row {
                    Text("${replies.size}")
                    TextButton(onClick = onClose) { Text("×") }
                }
            }

            Text(question.takeLast(500), fontSize = 12.sp, color = Color.Gray)

            if (loading) {
                LinearProgressIndicator(Modifier.fillMaxWidth())
            }

            errorMessage?.let {
                Text(it, fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
            }

            val shown = if (expanded) replies else replies.takeLast(1)
            LazyColumn(Modifier.heightIn(max = 260.dp)) {
                items(shown, key = { it.id }) { r ->
                    Text(
                        r.text,
                        Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        fontSize = 14.sp
                    )
                    TextButton(onClick = { clipboard.setText(AnnotatedString(r.text)) }) {
                        Text("Copy")
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Pass-through")
                Switch(
                    checked = passThrough,
                    onCheckedChange = {
                        passThrough = it
                        onTogglePassThrough(it)
                    }
                )
                TextButton(onClick = { expanded = !expanded }) {
                    Text(if (expanded) "Show less" else "View all")
                }
            }
        }
    }
}
