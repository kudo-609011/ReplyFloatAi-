# ReplyFloat AI Android

Android floating reply assistant. Build with Java 17 and Gradle 8.11.1.

GitHub Actions builds `app/build/outputs/apk/debug/app-debug.apk`.
