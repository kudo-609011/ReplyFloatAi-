package com.replyfloat.ai.service

import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import androidx.annotation.RequiresApi
import com.replyfloat.ai.data.AppPreferencesRepository
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first

@RequiresApi(Build.VERSION_CODES.N)
class QuickSettingsTileService : TileService() {

    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    override fun onStartListening() {
        super.onStartListening()
        updateTileState()
    }

    override fun onClick() {
        super.onClick()
        serviceScope.launch {
            val repo = AppPreferencesRepository.getInstance(applicationContext)
            val currentState = repo.isMasterEnabled.first()
            val newState = !currentState
            repo.setMasterEnabled(newState)

            if (newState) {
                FloatingOverlayService.startService(applicationContext)
            } else {
                FloatingOverlayService.stopService(applicationContext)
            }
            updateTileState()
        }
    }

    private fun updateTileState() {
        serviceScope.launch {
            val repo = AppPreferencesRepository.getInstance(applicationContext)
            val isEnabled = repo.isMasterEnabled.first()
            qsTile?.apply {
                state = if (isEnabled) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
                label = "ReplyFloat"
                updateTile()
            }
        }
    }

    override fun onDestroy() {
        serviceScope.cancel()
        super.onDestroy()
    }
}
