package com.replyfloat.ai.ui.overlay

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString

data class OverlayReply(val id:Long,val question:String,val text:String,val time:Long=System.currentTimeMillis())
@Composable fun FloatingOverlayContent(initialText:String,initialPackage:String,onClose:()->Unit,onDrag:(Float,Float)->Unit,onTogglePassThrough:(Boolean)->Unit){
 var question by remember{mutableStateOf(initialText)}; var replies by remember{mutableStateOf(listOf<OverlayReply>())}; var expanded by remember{mutableStateOf(false)}; var pass by remember{mutableStateOf(false)}; var loading by remember{mutableStateOf(false)}; val clipboard=LocalClipboardManager.current
 LaunchedEffect(initialText){ if(initialText.isNotBlank() && initialText!=question){question=initialText} }
 Card(Modifier.widthIn(min=260.dp,max=360.dp).pointerInput(Unit){detectDragGestures{change,drag->change.consume();onDrag(drag.x,drag.y)}}){ Column(Modifier.padding(12.dp).background(MaterialTheme.colorScheme.surface)){
  Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("ReplyFloat AI",fontSize=16.sp);Row{Text("${replies.size}");TextButton(onClick=onClose){Text("×")}}}
  Text(question.takeLast(500),fontSize=12.sp,color=Color.Gray); if(loading) LinearProgressIndicator(Modifier.fillMaxWidth())
  val shown=if(expanded) replies else replies.takeLast(1); LazyColumn(Modifier.heightIn(max=260.dp)){items(shown,key={it.id}){r->Text(r.text,Modifier.fillMaxWidth().padding(vertical=6.dp).pointerInput(Unit){},fontSize=14.sp);TextButton(onClick={clipboard.setText(AnnotatedString(r.text))}){Text("Copy")}}}
  Row(verticalAlignment=androidx.compose.ui.Alignment.CenterVertically){Text("Analyze");Switch(checked=pass,onCheckedChange{pass=it;onTogglePassThrough(it)});TextButton(onClick={expanded=!expanded}){Text(if(expanded)"Show less" else "View all")}}
 } }
}
