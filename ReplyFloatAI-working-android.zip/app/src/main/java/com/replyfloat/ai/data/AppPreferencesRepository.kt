package com.replyfloat.ai.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "replyfloat_settings")

class AppPreferencesRepository private constructor(private val context: Context) {
    companion object {
        val KEY_MASTER_ENABLED = booleanPreferencesKey("master_enabled")
        val KEY_PASS_THROUGH = booleanPreferencesKey("pass_through_mode")
        val KEY_TRANSPARENCY = floatPreferencesKey("transparency")
        val KEY_OVERLAY_SIZE = stringPreferencesKey("overlay_size")
        val KEY_REPLY_STYLE = stringPreferencesKey("reply_style")
        val KEY_SUGGESTION_COUNT = intPreferencesKey("suggestion_count")
        val KEY_RESPONSE_LENGTH = stringPreferencesKey("response_length")
        val KEY_DEBOUNCE_MS = longPreferencesKey("debounce_ms")
        val KEY_AUTO_DETECT = booleanPreferencesKey("auto_detect")
        val KEY_ALLOWED_PACKAGES = stringSetPreferencesKey("allowed_packages")
        val KEY_ACTIVE_PROVIDER = stringPreferencesKey("active_provider")
        val KEY_GEMINI_KEY = stringPreferencesKey("gemini_key")
        val KEY_OPENAI_KEY = stringPreferencesKey("openai_key")
        val KEY_OPENAI_ENDPOINT = stringPreferencesKey("openai_endpoint")
        val KEY_OPENAI_MODEL = stringPreferencesKey("openai_model")
        @Volatile private var INSTANCE: AppPreferencesRepository? = null
        fun getInstance(context: Context): AppPreferencesRepository = INSTANCE ?: synchronized(this) {
            INSTANCE ?: AppPreferencesRepository(context.applicationContext).also { INSTANCE = it }
        }
    }
    val isMasterEnabled: Flow<Boolean> = context.dataStore.data.map { it[KEY_MASTER_ENABLED] ?: true }
    val isPassThrough: Flow<Boolean> = context.dataStore.data.map { it[KEY_PASS_THROUGH] ?: false }
    val transparency: Flow<Float> = context.dataStore.data.map { it[KEY_TRANSPARENCY] ?: 0.90f }
    val debounceMs: Flow<Long> = context.dataStore.data.map { it[KEY_DEBOUNCE_MS] ?: 600L }
    val replyStyle: Flow<String> = context.dataStore.data.map { it[KEY_REPLY_STYLE] ?: "Passive" }
    val responseLength: Flow<String> = context.dataStore.data.map { it[KEY_RESPONSE_LENGTH] ?: "balanced" }
    val suggestionCount: Flow<Int> = context.dataStore.data.map { it[KEY_SUGGESTION_COUNT] ?: 3 }
    val activeProvider: Flow<String> = context.dataStore.data.map { it[KEY_ACTIVE_PROVIDER] ?: "gemini" }
    val allowedPackages: Flow<Set<String>> = context.dataStore.data.map { it[KEY_ALLOWED_PACKAGES] ?: setOf("com.whatsapp","com.reddit.frontpage","com.discord","com.twitter.android","com.android.chrome") }
    fun isAppAllowed(packageName: String): Flow<Boolean> = allowedPackages.map { it.contains(packageName) }
    fun getGeminiKey(): Flow<String> = context.dataStore.data.map { it[KEY_GEMINI_KEY] ?: "" }
    fun getOpenAIKey(): Flow<String> = context.dataStore.data.map { it[KEY_OPENAI_KEY] ?: "" }
    fun getOpenAIEndpoint(): Flow<String> = context.dataStore.data.map { it[KEY_OPENAI_ENDPOINT] ?: "https://api.openai.com/v1/chat/completions" }
    fun getOpenAIModel(): Flow<String> = context.dataStore.data.map { it[KEY_OPENAI_MODEL] ?: "gpt-4o-mini" }
    suspend fun setMasterEnabled(v:Boolean)=context.dataStore.edit{it[KEY_MASTER_ENABLED]=v}
    suspend fun setPassThrough(v:Boolean)=context.dataStore.edit{it[KEY_PASS_THROUGH]=v}
    suspend fun setTransparency(v:Float)=context.dataStore.edit{it[KEY_TRANSPARENCY]=v}
    suspend fun setReplyStyle(v:String)=context.dataStore.edit{it[KEY_REPLY_STYLE]=v}
    suspend fun setResponseLength(v:String)=context.dataStore.edit{it[KEY_RESPONSE_LENGTH]=v}
    suspend fun setSuggestionCount(v:Int)=context.dataStore.edit{it[KEY_SUGGESTION_COUNT]=v.coerceIn(1,5)}
    suspend fun setDebounceMs(v:Long)=context.dataStore.edit{it[KEY_DEBOUNCE_MS]=v.coerceIn(100,3000)}
    suspend fun setActiveProvider(v:String)=context.dataStore.edit{it[KEY_ACTIVE_PROVIDER]=v}
    suspend fun setGeminiKey(v:String)=context.dataStore.edit{it[KEY_GEMINI_KEY]=v}
    suspend fun setOpenAIKey(v:String)=context.dataStore.edit{it[KEY_OPENAI_KEY]=v}
    suspend fun setOpenAIEndpoint(v:String)=context.dataStore.edit{it[KEY_OPENAI_ENDPOINT]=v}
    suspend fun setOpenAIModel(v:String)=context.dataStore.edit{it[KEY_OPENAI_MODEL]=v}
    suspend fun toggleAllowedApp(packageName:String, allowed:Boolean)=context.dataStore.edit{ prefs -> val current=(prefs[KEY_ALLOWED_PACKAGES]?:emptySet()).toMutableSet(); if(allowed) current.add(packageName) else current.remove(packageName); prefs[KEY_ALLOWED_PACKAGES]=current }
}
