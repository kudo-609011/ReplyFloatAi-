package com.replyfloat.ai.ai

import com.replyfloat.ai.model.AIProviderConfig
import com.replyfloat.ai.model.ReplyRequest
import com.replyfloat.ai.model.ReplySuggestion

interface AIProvider {
    val id: String
    val name: String
    suspend fun generateReplies(request: ReplyRequest): Result<List<ReplySuggestion>>
    suspend fun testConnection(): Result<Boolean>
}

class AIProviderManager(
    private val providers: Map<String, AIProvider>
) {
    suspend fun generateReplies(
        providerId: String,
        request: ReplyRequest
    ): Result<List<ReplySuggestion>> {
        val provider = providers[providerId]
            ?: return Result.failure(IllegalArgumentException("Provider '$providerId' not found or disabled"))
        return provider.generateReplies(request)
    }

    companion object {
        fun createProvider(config: AIProviderConfig): AIProvider {
            return when (config.type.lowercase()) {
                "gemini" -> GeminiProvider(config)
                "openai" -> OpenAIProvider(config)
                "custom" -> CustomOpenAICompatibleProvider(config)
                else -> GeminiProvider(config)
            }
        }
    }
}
