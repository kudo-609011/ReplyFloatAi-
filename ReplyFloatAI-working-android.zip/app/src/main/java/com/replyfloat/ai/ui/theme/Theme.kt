package com.replyfloat.ai.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

val DeepSlateBackground = Color(0xFF090D16)
val CardSurfaceDark = Color(0xFF131B2A)
val CardSurfaceElevated = Color(0xFF1B263B)
val CyanAccent = Color(0xFF00E5FF)
val VioletAccent = Color(0xFF8B5CF6)
val TextPrimaryDark = Color(0xFFF1F5F9)
val TextSecondaryDark = Color(0xFF94A3B8)
val BorderDark = Color(0xFF2E3D56)

private val DarkColorScheme = darkColorScheme(
    primary = CyanAccent,
    secondary = VioletAccent,
    tertiary = Color(0xFF38BDF8),
    background = DeepSlateBackground,
    surface = CardSurfaceDark,
    surfaceVariant = CardSurfaceElevated,
    onPrimary = Color.Black,
    onSecondary = Color.White,
    onBackground = TextPrimaryDark,
    onSurface = TextPrimaryDark,
    outline = BorderDark
)

@Composable
fun ReplyFloatAITheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = DarkColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = DeepSlateBackground.toArgb()
            window.navigationBarColor = DeepSlateBackground.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        content = content
    )
}
