package com.replyfloat.ai.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.replyfloat.ai.data.AppPreferencesRepository
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first

/**
 * Legitimate Android Accessibility Service that inspects visible text nodes
 * ONLY on applications selected in the user's whitelist.
 * Zero screenshots, zero continuous battery drain, debounced text extraction.
 */
class ReplyFloatAccessibilityService : AccessibilityService() {

    private val serviceScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private val debounceHandler = Handler(Looper.getMainLooper())
    private var pendingDebounceRunnable: Runnable? = null
    private var lastExtractedText = ""
    private var lastPackage = ""

    override fun onServiceConnected() {
        super.onServiceConnected()
        serviceInfo = AccessibilityServiceInfo().apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                    AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED or
                    AccessibilityEvent.TYPE_VIEW_SCROLLED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            notificationTimeout = 300
            flags = AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS or
                    AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val packageName = event.packageName?.toString() ?: return

        // Ignore our own package
        if (packageName == applicationContext.packageName) return

        serviceScope.launch {
            val repository = AppPreferencesRepository.getInstance(applicationContext)
            val isEnabled = repository.isMasterEnabled.first()
            if (!isEnabled) return@launch

            val isAllowed = repository.isAppAllowed(packageName).first()
            if (!isAllowed) return@launch

            val debounceTime = repository.debounceMs.first()

            // Debounce processing to avoid triggering on every character or micro scroll
            pendingDebounceRunnable?.let { debounceHandler.removeCallbacks(it) }
            pendingDebounceRunnable = Runnable {
                extractVisibleTextAsync(packageName)
            }
            debounceHandler.postDelayed(pendingDebounceRunnable!!, debounceTime)
        }
    }

    private fun extractVisibleTextAsync(packageName: String) {
        val rootNode = rootInActiveWindow ?: return
        try {
            val textBuilder = StringBuilder()
            traverseNode(rootNode, textBuilder)
            val extracted = textBuilder.toString().trim()

            if (extracted.isNotEmpty() && extracted != lastExtractedText) {
                lastExtractedText = extracted
                lastPackage = packageName

                // Dispatch to floating overlay service
                FloatingOverlayService.startService(
                    context = applicationContext,
                    text = extracted,
                    pkg = packageName
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            rootNode.recycle()
        }
    }

    private fun traverseNode(node: AccessibilityNodeInfo?, builder: StringBuilder) {
        if (node == null) return
        if (node.text != null && node.text.isNotBlank()) {
            val textStr = node.text.toString().trim()
            // Ignore trivial single character or numeric timestamps
            if (textStr.length > 2) {
                builder.append(textStr).append("\\n")
            }
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            traverseNode(child, builder)
            child.recycle()
        }
    }

    override fun onInterrupt() {
        pendingDebounceRunnable?.let { debounceHandler.removeCallbacks(it) }
    }

    override fun onDestroy() {
        serviceScope.cancel()
        pendingDebounceRunnable?.let { debounceHandler.removeCallbacks(it) }
        super.onDestroy()
    }
}
