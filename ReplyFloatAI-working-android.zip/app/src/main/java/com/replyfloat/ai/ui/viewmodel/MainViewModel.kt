package com.replyfloat.ai.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.replyfloat.ai.data.AppPreferencesRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class HistoryItem(val id:Long,val text:String,val timestamp:Long=System.currentTimeMillis())
data class MainUiState(val enabled:Boolean=true,val style:String="Passive",val geminiKey:String="",val history:List<HistoryItem> = emptyList())
class MainViewModel(app:Application):AndroidViewModel(app){
 private val repo=AppPreferencesRepository.getInstance(app); private val _state=MutableStateFlow(MainUiState()); val state:StateFlow<MainUiState> = _state.asStateFlow()
 val styles=listOf("Passive","1 line","2 lines","Single word","Debate","Funny","Arrogant","Lord")
 init{ viewModelScope.launch{ combine(repo.isMasterEnabled,repo.replyStyle,repo.getGeminiKey()){a,b,c->Triple(a,b,c)}.collect{(a,b,c)->_state.update{it.copy(enabled=a,style=b,geminiKey=c)}} } }
 fun setEnabled(v:Boolean){viewModelScope.launch{repo.setMasterEnabled(v)}}
 fun setStyle(v:String){viewModelScope.launch{repo.setReplyStyle(v)}}
 fun setGeminiKey(v:String){_state.update{it.copy(geminiKey=v)}}
 fun saveSettings(){viewModelScope.launch{repo.setGeminiKey(_state.value.geminiKey)}}
 fun addHistory(text:String){_state.update{it.copy(history=(it.history+HistoryItem(System.nanoTime(),text)).takeLast(50))}}
 fun clearHistory(){_state.update{it.copy(history=emptyList())}}
}
